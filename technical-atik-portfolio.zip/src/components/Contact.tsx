import { motion } from 'motion/react';
import { Mail, MapPin } from 'lucide-react';

export function Contact() {
  return (
    <section id="contact" className="py-24 px-4 relative mt-12">
      {/* Decorative gradient line at the top of footer area */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-px bg-gradient-to-r from-transparent via-teal-900/50 to-transparent" />
      
      <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Let's Work Together</h2>
          <p className="text-gray-400 max-w-lg mx-auto mb-12">
            Whether you need a sleek website, professional video editing, or just want to say hi, my inbox is always open.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16">
            <a 
              href="mailto:Technicalatik@gmail.com"
              className="group flex items-center gap-3 px-8 py-4 bg-teal-600 hover:bg-teal-500 rounded-full text-white font-semibold transition-all shadow-[0_0_20px_rgba(20,184,166,0.2)] hover:shadow-[0_0_40px_rgba(20,184,166,0.5)] hover:-translate-y-1"
            >
              <Mail size={20} className="group-hover:animate-bounce" />
              Technicalatik@gmail.com
            </a>
          </div>

          <div className="flex items-center justify-center gap-2 text-gray-500 font-medium bg-gray-900/50 px-6 py-3 rounded-full border border-gray-800 w-max mx-auto">
            <MapPin size={18} className="text-teal-500" />
            Uttara, Dhaka, Bangladesh
          </div>
        </motion.div>

        <div className="mt-24 text-gray-600 text-sm">
          <p>© {new Date().getFullYear()} Technical Atik. Crafted with precision.</p>
        </div>
      </div>
    </section>
  );
}
