import { motion } from 'motion/react';
import { useTypewriter } from '../hooks/useTypewriter';

export function Hero() {
  const words = [
    'Top Freelancer',
    'Creative Video Editor',
    'Web Developer',
    'Ethical Hacking Enthusiast',
  ];
  const typingText = useTypewriter({ words, typingSpeed: 80, deletingSpeed: 50 });

  return (
    <section className="min-h-screen flex flex-col items-center justify-center pt-20 pb-12 px-4 relative overflow-hidden">
      {/* Background glowing orb */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal-600/20 rounded-full blur-[120px] -z-10 pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="flex flex-col items-center text-center max-w-4xl mx-auto"
      >
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="relative mb-8"
        >
          <div className="w-48 h-48 rounded-full p-1 bg-gradient-to-tr from-teal-500 to-teal-200/20 relative z-10 shadow-[0_0_40px_rgba(20,184,166,0.3)]">
            <img
              src="https://raw.githubusercontent.com/TechnicalAtik-4/technicalatik/main/png/professional-profile-picture%20Technical%20Atik.png"
              alt="Technical Atik"
              className="w-full h-full rounded-full object-cover bg-gray-900 border-4 border-gray-950"
              onError={(e) => {
                (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=Technical+Atik&background=0d1117&color=14b8a6&size=256&font-size=0.33`;
              }}
            />
          </div>
        </motion.div>

        <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-4">
          Hi, I'm <span className="text-teal-400">Technical Atik</span>
        </h1>
        
        <div className="h-12 flex items-center justify-center">
          <p className="text-xl md:text-3xl text-gray-400 font-medium">
            I am a <span className="text-teal-300 font-mono border-r-2 border-teal-400 pr-1 animate-pulse">{typingText}</span>
          </p>
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="mt-12 flex flex-col sm:flex-row gap-4"
        >
          <a href="#contact" className="px-8 py-3 rounded-full bg-teal-600 hover:bg-teal-500 text-white font-medium transition-colors shadow-[0_0_20px_rgba(20,184,166,0.2)] hover:shadow-[0_0_30px_rgba(20,184,166,0.4)]">
            Get In Touch
          </a>
          <a href="#about" className="px-8 py-3 rounded-full bg-gray-800 hover:bg-gray-700 text-white font-medium transition-colors border border-gray-700">
            About Me
          </a>
        </motion.div>
      </motion.div>
    </section>
  );
}
